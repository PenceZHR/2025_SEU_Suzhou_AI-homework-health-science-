


import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score


class EfficientNetB0(nn.Module):
    def __init__(self, in_channels=1, num_classes=4):
        super(EfficientNetB0, self).__init__()
        # 加载预训练的EfficientNet-B0
        self.backbone = models.efficientnet_b0(pretrained=True)
        # 修改输入层（适配单通道医学图像）
        self.backbone.features[0][0] = nn.Conv2d(
            in_channels, 32, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False
        )
        # 修改分类层（适配4分类任务）
        in_features = self.backbone.classifier[1].in_features
        self.backbone.classifier = nn.Sequential(
            nn.Dropout(p=0.2, inplace=True),
            nn.Linear(in_features, num_classes)
        )

    def forward(self, x):
        return self.backbone(x)


#2. 评估函数（不变）
def get_evaluation_metrics(y_true, y_pred, task='multiclass'):
    y_true = np.array(y_true).flatten()
    y_pred = np.array(y_pred).flatten()

    metrics = {}
    metrics['accuracy'] = accuracy_score(y_true, y_pred)
    average = 'macro' if task == 'multiclass' else 'binary'
    metrics['precision'] = precision_score(y_true, y_pred, average=average, zero_division=0)
    metrics['recall'] = recall_score(y_true, y_pred, average=average, zero_division=0)
    metrics['f1'] = f1_score(y_true, y_pred, average=average, zero_division=0)

    return metrics


#  3. 自定义医学图像数据集加载（不变）
class MedicalImageDataset(Dataset):
    def __init__(self, img_paths, labels, transform=None):
        self.img_paths = img_paths
        self.labels = labels
        self.transform = transform

    def __len__(self):
        return len(self.img_paths)

    def __getitem__(self, idx):
        # 加载图像（支持单通道/三通道医学图像）
        img_path = self.img_paths[idx]
        img = Image.open(img_path).convert('L')  # 'L'表示单通道灰度图
        label = self.labels[idx]

        if self.transform:
            img = self.transform(img)

        return img, torch.tensor(label, dtype=torch.long)


# 数据预处理与加载（适配EfficientNet分辨率）
def load_medical_data(data_root, test_size=0.2, batch_size=32):
    """
    加载医学图像数据集（按文件夹分类：data_root/类别1/xxx.png）
    """
    # 1. 遍历文件夹，收集图像路径和标签
    class_names = os.listdir(data_root)
    class2idx = {name: i for i, name in enumerate(class_names)}
    img_paths = []
    labels = []

    for class_name in class_names:
        class_dir = os.path.join(data_root, class_name)
        if not os.path.isdir(class_dir):
            continue
        for img_name in os.listdir(class_dir):
            img_path = os.path.join(class_dir, img_name)
            if img_name.endswith(('.png', '.jpg', '.jpeg', '.tif')):
                img_paths.append(img_path)
                labels.append(class2idx[class_name])

    # 2. 划分训练集/测试集（val集=test集）
    train_paths, val_paths, train_labels, val_labels = train_test_split(
        img_paths, labels, test_size=test_size, random_state=42, stratify=labels
    )

    # 3. 数据增强（适配EfficientNet的输入分辨率224×224，医学图像增强更充分）
    train_transform = transforms.Compose([
        transforms.Resize((224, 224)),  # EfficientNet推荐分辨率
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomRotation(15),
        transforms.RandomAffine(degrees=0, translate=(0.1, 0.1)),  # 平移增强
        transforms.GaussianBlur(kernel_size=3, sigma=(0.1, 2.0)),  # 模拟医学扫描噪声
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5], std=[0.5])  # 单通道归一化
    ])

    val_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5], std=[0.5])
    ])

    # 4. 创建DataLoader
    train_dataset = MedicalImageDataset(train_paths, train_labels, train_transform)
    val_dataset = MedicalImageDataset(val_paths, val_labels, val_transform)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

    return train_loader, val_loader, class_names


# ===================== 5. 模型训练与验证（核心修改：输出train/val的loss+acc） =====================
def train_model(model, train_loader, val_loader, num_epochs=20, lr=0.001, device='cuda'):
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.8)

    # 记录训练过程
    train_losses = []
    train_accs = []
    val_losses = []
    val_accs = []
    best_acc = 0.0  # 记录最优准确率
    best_model_path = 'best_medical_efficientnet_b3.pth'  # 最优模型保存路径

    model.to(device)
    for epoch in range(num_epochs):
        # 训练阶段：计算train loss + train acc
        model.train()
        train_loss = 0.0
        train_true = []
        train_pred = []
        for imgs, labels in train_loader:
            imgs, labels = imgs.to(device), labels.to(device)

            optimizer.zero_grad()
            outputs = model(imgs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            # 累加训练损失
            train_loss += loss.item() * imgs.size(0)
            # 收集训练集预测结果（计算train acc）
            train_true.extend(labels.cpu().numpy())
            train_pred.extend(torch.argmax(outputs, dim=1).cpu().numpy())

        # 计算训练集最终指标
        train_loss /= len(train_loader.dataset)
        train_metrics = get_evaluation_metrics(train_true, train_pred)
        train_acc = train_metrics['accuracy']
        train_losses.append(train_loss)
        train_accs.append(train_acc)

        #  验证阶段：计算val loss + val acc
        model.eval()
        val_loss = 0.0
        val_true = []
        val_pred = []
        with torch.no_grad():
            for imgs, labels in val_loader:
                imgs, labels = imgs.to(device), labels.to(device)
                outputs = model(imgs)
                loss = criterion(outputs, labels)

                # 累加验证损失
                val_loss += loss.item() * imgs.size(0)
                # 收集验证集预测结果（计算val acc）
                val_true.extend(labels.cpu().numpy())
                val_pred.extend(torch.argmax(outputs, dim=1).cpu().numpy())

        # 计算验证集最终指标
        val_loss /= len(val_loader.dataset)
        val_metrics = get_evaluation_metrics(val_true, val_pred)
        val_acc = val_metrics['accuracy']
        val_losses.append(val_loss)
        val_accs.append(val_acc)

        # 保存最优模型
        if val_acc > best_acc:
            best_acc = val_acc  # 更新最优准确率
            torch.save(model.state_dict(), best_model_path)  # 保存当前最优模型
            print(f"[最优模型更新] Epoch {epoch + 1} | 验证集准确率从 {best_acc:.4f} 提升至 {val_acc:.4f}，已保存")

        # 打印核心日志：train loss/train acc | val loss/val acc（保留precision/recall/f1辅助）
        print(f'Epoch [{epoch + 1}/{num_epochs}] | '
              f'train_loss={train_loss:.4f} train_acc={train_acc:.4f} | '
              f'val_loss={val_loss:.4f} val_acc={val_acc:.4f} | '
              f'Precision: {val_metrics["precision"]:.4f} | Recall: {val_metrics["recall"]:.4f} | F1: {val_metrics["f1"]:.4f}')

        scheduler.step()

    # 绘制训练曲线（新增train/val loss+acc对比）
    plt.figure(figsize=(12, 4))
    # 子图1：Loss对比
    plt.subplot(1, 2, 1)
    plt.plot(train_losses, label='Train Loss', color='blue')
    plt.plot(val_losses, label='Val Loss', color='orange')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training & Validation Loss')
    plt.legend()

    # 子图2：Accuracy对比
    plt.subplot(1, 2, 2)
    plt.plot(train_accs, label='Train Acc', color='red')
    plt.plot(val_accs, label='Val Acc', color='green')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.title('Training & Validation Accuracy')
    plt.legend()
    plt.tight_layout()
    plt.show()

    # 加载最优模型
    model.load_state_dict(torch.load(best_model_path))
    print(f"\n训练完成！最优验证集准确率：{best_acc:.4f}，已加载到模型中")
    return model


# ===================== 6. 主函数（一键运行） =====================
if __name__ == '__main__':
    # 配置参数
    DATA_ROOT = './dataset2'  # 替换为你的医学图像数据集根目录
    NUM_CLASSES = 4  # 分类类别数（如正常/肺炎/肺结核/肺癌）
    IN_CHANNELS = 1  # 1=单通道灰度图
    BATCH_SIZE = 32  # EfficientNet参数量稍大，批量大小可适当减小（根据显存调整）
    NUM_EPOCHS = 50
    LR = 0.001
    DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'

    # 1. 加载数据
    print("Loading data...")
    train_loader, val_loader, class_names = load_medical_data(DATA_ROOT, batch_size=BATCH_SIZE)
    print(f"Data loaded! Train samples: {len(train_loader.dataset)}, Val samples: {len(val_loader.dataset)}")
    print(f"Class names: {class_names}")

    # 2. 初始化模型（替换为EfficientNet-B0）
    model = EfficientNetB0(in_channels=IN_CHANNELS, num_classes=NUM_CLASSES)
    print(f"Model initialized: EfficientNet-B0 (in_channels={IN_CHANNELS}, num_classes={NUM_CLASSES})")

    # 3. 训练模型
    print("Start training...")
    trained_model = train_model(model, train_loader, val_loader, NUM_EPOCHS, LR, DEVICE)

    # 4. 保存模型
    torch.save(trained_model.state_dict(), 'medical_efficientnet_b0.pth')
    print("Model saved as 'medical_efficientnet_b1.pth'")


